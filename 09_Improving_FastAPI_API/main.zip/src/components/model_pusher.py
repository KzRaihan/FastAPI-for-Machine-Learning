from src.components.model_trainer import train_model
import pickle
# method 8: download the trained model
def download_model():
    model, _, _ = train_model()

    # Save the trained pipeline using pickle
    pickle_model_path = "../artifact/trained_model/model.pkl"
    
    with open(pickle_model_path, "wb") as f:
        pickle.dump(model, f)