# Import Necessary Libraries
import pandas as pd
from pandas import DataFrame

# load the data
def load_data() -> DataFrame:
    file_path = "../artifact/data/insurance.csv"
    try:
        df = pd.read_csv(file_path)
        print(f"File is Loaded Successfully")

        return df
    except Exception as e:
        raise FileNotFoundError(f"No such file or directory. Original error: {e}")
    