from src.components.data_transformation import split_X_y, ML_pipeline
from sklearn.model_selection import train_test_split

# Method 6: train_model
def train_model():
    X, y = split_X_y()
   
    pipeline = ML_pipeline()

    # Split data and train model
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1)
    
    model = pipeline.fit(X_train, y_train)

    return model, X_test, y_test