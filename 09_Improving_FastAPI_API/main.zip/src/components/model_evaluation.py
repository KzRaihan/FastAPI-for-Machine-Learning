
from src.components.model_trainer import train_model

# method 7: evaluation the model
def evaluation(model):
    model, X_test, y_test = train_model()
    
    y_pred = model.predict(X_test)

    accuracy_score = accuracy_score(y_test, y_pred)

    classification_report = classification_report(y_test, y_pred)

    return accuracy_score, classification_report