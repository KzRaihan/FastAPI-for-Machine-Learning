from src.components.model_pusher import download_model

if __name__ == "__main__":
    download_model()

